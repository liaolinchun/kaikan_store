;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/home/base/pageHot"],{"00b0":function(t,n,e){"use strict";e.r(n);var u=e("6e5f"),o=e.n(u);for(var a in u)"default"!==a&&function(t){e.d(n,t,function(){return u[t]})}(a);n["default"]=o.a},"42c0":function(t,n,e){"use strict";var u=e("eb93"),o=e.n(u);o.a},4342:function(t,n,e){"use strict";e.r(n);var u=e("9203"),o=e("00b0");for(var a in o)"default"!==a&&function(t){e.d(n,t,function(){return o[t]})}(a);e("42c0");var i,r=e("f0c5"),c=Object(r["a"])(o["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],i);n["default"]=c.exports},"6e5f":function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={props:["hotList","showTitle"],data:function(){return{hotLists:this.hotList}},methods:{navToDetailPage:function(n){t.navigateTo({url:"../good/goods?goods_id="+n.id})}}};n.default=e}).call(this,e("c11b")["default"])},9203:function(t,n,e){"use strict";var u,o=function(){var t=this,n=t.$createElement;t._self._c},a=[];e.d(n,"b",function(){return o}),e.d(n,"c",function(){return a}),e.d(n,"a",function(){return u})},eb93:function(t,n,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/home/base/pageHot-create-component',
    {
        'pages/home/base/pageHot-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("4342"))
        })
    },
    [['pages/home/base/pageHot-create-component']]
]);
