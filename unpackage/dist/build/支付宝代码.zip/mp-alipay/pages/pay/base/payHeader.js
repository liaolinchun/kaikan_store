;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/pay/base/payHeader"],{"2a85":function(n,t,a){"use strict";a.r(t);var e=a("db9a"),u=a("9959");for(var r in u)"default"!==r&&function(n){a.d(t,n,function(){return u[n]})}(r);a("4151");var f,c=a("f0c5"),o=Object(c["a"])(u["default"],e["b"],e["c"],!1,null,null,null,!1,e["a"],f);t["default"]=o.exports},4151:function(n,t,a){"use strict";var e=a("f509"),u=a.n(e);u.a},9959:function(n,t,a){"use strict";a.r(t);var e=a("a440"),u=a.n(e);for(var r in e)"default"!==r&&function(n){a.d(t,n,function(){return e[n]})}(r);t["default"]=u.a},a440:function(n,t,a){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={props:["goodsInfo","addressData"],data:function(){return{}}};t.default=e},db9a:function(n,t,a){"use strict";var e,u=function(){var n=this,t=n.$createElement;n._self._c},r=[];a.d(t,"b",function(){return u}),a.d(t,"c",function(){return r}),a.d(t,"a",function(){return e})},f509:function(n,t,a){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/pay/base/payHeader-create-component',
    {
        'pages/pay/base/payHeader-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("2a85"))
        })
    },
    [['pages/pay/base/payHeader-create-component']]
]);
