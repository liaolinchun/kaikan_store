;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/good/goodsEval"],{"08b1":function(t,n,a){},"0a93":function(t,n,a){"use strict";a.r(n);var u=a("3f0b"),e=a.n(u);for(var o in u)"default"!==o&&function(t){a.d(n,t,function(){return u[t]})}(o);n["default"]=e.a},3004:function(t,n,a){"use strict";var u=a("08b1"),e=a.n(u);e.a},"3f0b":function(t,n,a){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={props:["goodsData"],data:function(){return{}},methods:{toRatings:function(){t.setStorageSync("comments",this.goodsData),t.navigateTo({url:"./base/ratings"})}}};n.default=a}).call(this,a("c11b")["default"])},cb44:function(t,n,a){"use strict";a.r(n);var u=a("d81f"),e=a("0a93");for(var o in e)"default"!==o&&function(t){a.d(n,t,function(){return e[t]})}(o);a("3004");var r,c=a("f0c5"),f=Object(c["a"])(e["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],r);n["default"]=f.exports},d81f:function(t,n,a){"use strict";var u,e=function(){var t=this,n=t.$createElement;t._self._c},o=[];a.d(n,"b",function(){return e}),a.d(n,"c",function(){return o}),a.d(n,"a",function(){return u})}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/good/goodsEval-create-component',
    {
        'pages/good/goodsEval-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("cb44"))
        })
    },
    [['pages/good/goodsEval-create-component']]
]);
