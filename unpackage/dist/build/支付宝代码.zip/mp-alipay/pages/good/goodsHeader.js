;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/good/goodsHeader"],{2258:function(n,t,u){"use strict";var c,e=function(){var n=this,t=n.$createElement;n._self._c},f=[];u.d(t,"b",function(){return e}),u.d(t,"c",function(){return f}),u.d(t,"a",function(){return c})},4619:function(n,t,u){"use strict";var c=u("bcc9"),e=u.n(c);e.a},"4fbf":function(n,t,u){"use strict";u.r(t);var c=u("f4d5"),e=u.n(c);for(var f in c)"default"!==f&&function(n){u.d(t,n,function(){return c[n]})}(f);t["default"]=e.a},bcc9:function(n,t,u){},cf08:function(n,t,u){"use strict";u.r(t);var c=u("2258"),e=u("4fbf");for(var f in e)"default"!==f&&function(n){u.d(t,n,function(){return e[n]})}(f);u("4619");var a,r=u("f0c5"),o=Object(r["a"])(e["default"],c["b"],c["c"],!1,null,null,null,!1,c["a"],a);t["default"]=o.exports},f4d5:function(n,t,u){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={data:function(){return{}},onLoad:function(){this.showBack=!1},methods:{back:function(){n.navigateBack()}}};t.default=u}).call(this,u("c11b")["default"])}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/good/goodsHeader-create-component',
    {
        'pages/good/goodsHeader-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("cf08"))
        })
    },
    [['pages/good/goodsHeader-create-component']]
]);
